GREAT COROLLA GARAGE — SOURCE ANDROID OFFLINE

Isi:
- app/src/main/assets/index.html : aplikasi offline
- app/src/main/java/.../MainActivity.java : Android WebView
- konfigurasi Gradle untuk dibuka di Android Studio

Cara build APK:
1. Buka folder GreatCorollaGarage di Android Studio.
2. Tunggu Gradle Sync selesai (pertama kali perlu internet untuk mengunduh Android Gradle Plugin/SDK).
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- Setelah terpasang, aplikasi dan fitur pencatatan bekerja offline.
- Data disimpan lokal pada perangkat; uninstall aplikasi dapat menghapus data.
- Gunakan tombol Export backup secara berkala.
- Versi awal ini belum punya sinkronisasi cloud.


BUILD APK VIA CLOUD (TANPA LAPTOP):
1. Buat/login akun GitHub melalui browser HP.
2. Buat repository baru bernama great-corolla-garage.
3. Upload seluruh isi ZIP project ini ke repository (bukan file ZIP-nya).
4. Buka tab Actions dan izinkan Actions jika diminta.
5. Workflow "Build Great Corolla Garage APK" akan berjalan otomatis.
6. Buka hasil workflow yang selesai, bagian Artifacts, lalu download
   Great-Corolla-Garage-APK. Ekstrak ZIP artifact untuk mendapatkan app-debug.apk.
7. Buka APK di HP untuk instalasi. Android mungkin meminta izin instalasi
   aplikasi dari browser/file manager yang digunakan.

Catatan: GitHub memerlukan akun dan internet untuk proses build cloud pertama kali.
